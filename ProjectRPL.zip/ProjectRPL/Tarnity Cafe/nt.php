<!-- <ul class="navbar-nav navbar-nav-hover ms-auto">
                                <li class=" nav-item my-auto ms-3 ms-lg-auto">
                                    <form class=" d-flex input-group input-group-outline my-3"><input class="form-control text-white borde" type="search" placeholder="  Search" aria-label="Search">
                                        <a href="" class="btn btn-icon bg-gradient-primary  mb-0 me-1 mt-2 mt-md-0"><i class="material-icons">search</i></a>
                                    </form>
                                </li>
                            </ul> -->

<?php echo number_format(1000000)?>
