<?php
	$hostname	= "sql211.infinityfree.com"; //bawaan
	$username	= "if0_34392096"; //bawaan
	$password	= "KMaK6MQ1J6ReI"; //kosong
	$database	= "if0_34392096_tokotopup"; //nama database yang akan dikoneksikan

	$connect	= new mysqli($hostname, $username, $password, $database); //query koneksi

	if($connect->connect_error) { //cek error
		die("Error : ".$connect->connect_error);
	}
?>