-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2023 at 06:13 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tokotopup`
--

-- --------------------------------------------------------

--
-- Table structure for table `akun`
--

CREATE TABLE `akun` (
  `id_akun` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `akun`
--

INSERT INTO `akun` (`id_akun`, `username`, `password`, `email`) VALUES
(2, 'febrian', '100203', 'febrian@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `apex`
--

CREATE TABLE `apex` (
  `id` int(2) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `harga` int(10) NOT NULL,
  `icon` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `apex`
--

INSERT INTO `apex` (`id`, `nama`, `harga`, `icon`) VALUES
(1, 'Arabika', 5300, './assets/img/coffee.png'),
(2, 'Robuska', 10700, './assets/img/coffee.png'),
(3, 'Milk Coffe', 16000, './assets/img/coffee.png'),
(4, 'Taro Coffe', 35000, './assets/img/coffee.png'),
(5, 'Black Coffe', 15000, './assets/img/coffee.png'),
(6, 'White Coffe', 6500, './assets/img/coffee.png');

-- --------------------------------------------------------

--
-- Table structure for table `gi`
--

CREATE TABLE `gi` (
  `id` int(1) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `harga` int(10) NOT NULL,
  `icon` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gi`
--

INSERT INTO `gi` (`id`, `nama`, `harga`, `icon`) VALUES
(1, 'Kue Tart', 15000, './assets/img/dessert.png'),
(2, 'Siffon Keju', 12000, './assets/img/dessert.png'),
(3, 'Coffe Cake', 10000, './assets/img/dessert.png'),
(4, 'Bolu Pandan', 18000, './assets/img/dessert.png'),
(5, 'Bolu Keju', 18000, './assets/img/dessert.png'),
(6, 'Roti Bakar', 20000, './assets/img/dessert.png'),
(7, 'Roti Keju', 20000, './assets/img/dessert.png');

-- --------------------------------------------------------

--
-- Table structure for table `mlbb`
--

CREATE TABLE `mlbb` (
  `id` int(2) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `harga` int(10) NOT NULL,
  `icon` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mlbb`
--

INSERT INTO `mlbb` (`id`, `nama`, `harga`, `icon`) VALUES
(1, 'Nasi Goreng Kambing', 12000, './assets/img/snacks.png'),
(2, 'Nasi Goreng Sapi', 12000, './assets/img/snacks.png'),
(3, 'Nasi Goreng Campur', 10000, './assets/img/snacks.png'),
(4, 'Mie Goreng Jeroan', 15000, './assets/img/snacks.png'),
(5, 'Mie Goreng Campur', 13000, './assets/img/snacks.png'),
(6, 'Bubur Sapi', 8000, './assets/img/snacks.png'),
(7, 'Bubur Ayam', 15000, './assets/img/snacks.png'),
(8, 'Bihun Goreng', 24000, './assets/img/snacks.png'),
(9, 'Bihun Rebus', 12000, './assets/img/snacks.png'),
(10, 'Kentang Goreng', 19000, './assets/img/snacks.png');

-- --------------------------------------------------------

--
-- Table structure for table `pubgm`
--

CREATE TABLE `pubgm` (
  `id` int(2) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `harga` int(10) NOT NULL,
  `icon` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pubgm`
--

INSERT INTO `pubgm` (`id`, `nama`, `harga`, `icon`) VALUES
(1, 'Aqua', 5000, './assets/img/bottle.png'),
(2, 'Le Minerale', 7000, './assets/img/bottle.png'),
(3, 'Ades', 10000, './assets/img/bottle.png'),
(4, 'Crystalink', 14000, './assets/img/bottle.png'),
(5, 'Amanah', 20000, './assets/img/bottle.png'),
(6, 'Cleo', 25000, './assets/img/bottle.png'),
(7, 'Pelangi', 50000, './assets/img/bottle.png'),
(8, 'Daxu', 10000, './assets/img/bottle.png');

-- --------------------------------------------------------

--
-- Table structure for table `tof`
--

CREATE TABLE `tof` (
  `id` int(1) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `harga` int(10) NOT NULL,
  `icon` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tof`
--

INSERT INTO `tof` (`id`, `nama`, `harga`, `icon`) VALUES
(1, 'Thai Tea', 16000, './assets/img/drinks.png'),
(2, 'Teh Tarik', 7900, './assets/img/drinks.png'),
(3, 'Teh Susu', 20000, './assets/img/drinks.png'),
(4, 'Mineral Susu', 4700, './assets/img/drinks.png'),
(5, 'Cocholatos', 8000, './assets/img/drinks.png'),
(6, 'Boba Manis', 15000, './assets/img/drinks.png');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `no_transaksi` int(11) NOT NULL,
  `produk` varchar(50) NOT NULL,
  `harga` int(10) NOT NULL,
  `bayar` varchar(50) NOT NULL,
  `id_akun` int(11) NOT NULL,
  `game` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `valorant`
--

CREATE TABLE `valorant` (
  `id` int(1) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `harga` int(10) NOT NULL,
  `icon` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `valorant`
--

INSERT INTO `valorant` (`id`, `nama`, `harga`, `icon`) VALUES
(1, 'Chitatos', 15000, './assets/img/snacks.png'),
(2, 'Kentang Rebus', 5000, './assets/img/snacks.png'),
(3, 'Taro', 8000, './assets/img/snacks.png'),
(4, 'Ciki Ball', 15000, './assets/img/snacks.png'),
(5, 'Micin Lidi', 2500, './assets/img/snacks.png'),
(6, 'Jamur Goreng', 4000, './assets/img/snacks.png'),
(7, 'Jamur Rebus', 8000, './assets/img/snacks.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `akun`
--
ALTER TABLE `akun`
  ADD PRIMARY KEY (`id_akun`);

--
-- Indexes for table `apex`
--
ALTER TABLE `apex`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gi`
--
ALTER TABLE `gi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mlbb`
--
ALTER TABLE `mlbb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pubgm`
--
ALTER TABLE `pubgm`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tof`
--
ALTER TABLE `tof`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`no_transaksi`),
  ADD KEY `id_akun` (`id_akun`);

--
-- Indexes for table `valorant`
--
ALTER TABLE `valorant`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `akun`
--
ALTER TABLE `akun`
  MODIFY `id_akun` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `no_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `id_akun` FOREIGN KEY (`id_akun`) REFERENCES `akun` (`id_akun`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
